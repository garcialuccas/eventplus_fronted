import Footer from "../../components/footer/footer";
import Header from "../../components/header/Header";
import "./Usuarios.css"

function Usuarios() {
    <>
    <Header />
    <main className="cadastro-usuario-page">

    </main>
    <Footer />
    </>
}

export default Usuarios;